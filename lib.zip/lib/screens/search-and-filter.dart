/*import 'package:flutter/material.dart';

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          toolbarHeight: 80,
          backgroundColor: Colors.white,
          actions: [
           
            IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.black,
                size: 30,
              ),
              onPressed: () {
                //showSearch(context: context, delegate:null);
              },
            ),
          ],
          leading: IconButton(
            icon: Image.asset(
              'assets/images/ink-logo-black-01.png',
              width: 100,
              height: 100,
            ),
            onPressed: () {},
          ),
        ),
        body: Center(
          child: Text('Hello '),
        ),
      ),
    );
  }
}*/
