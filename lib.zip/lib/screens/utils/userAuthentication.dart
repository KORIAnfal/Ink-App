import 'dart:convert';

import 'package:dio/dio.dart';

import 'package:ink/constants/endpoints.dart';
import 'package:ink/main.dart';
import 'package:ink/models/seller.dart';

class UserAuthentication {
  static Future<Seller?> getLoggedUser() async {
    String? uid = prefs?.getString("user_id");
    String? email = prefs?.getString("user_email");
    String? password = prefs?.getString("user_password");
    if (uid != null &&
        email != null &&
        password != null &&
        uid.isNotEmpty &&
        email.isNotEmpty &&
        password.isNotEmpty) {
      return User(
          uid: uid, name: 'Your name', email: email, password: password);
    } else
      return null;
  }

  static Future<String> loginUser(String email, String password) async {
    //verify::
    Map<String, dynamic> form_data = {'email': email, 'password': password};

    var response = await dio.post(api_endpoint_user_login,
        data: FormData.fromMap(form_data));

    print(response);
    String error_msg = '';
    Map ret_data = jsonDecode(response.toString());
    if (ret_data['status'] == 200) {
      Map<String, dynamic> data = ret_data['data'];
      if (prefs != null) {
        prefs!.setString("user_id", "${data['id']}");
        prefs!.setString("user_email", data['email']);
        prefs!.setString("user_password", data['password']);
      }
      return 'success';
    }
    error_msg = ret_data?['message'];
    return 'Error : $error_msg';
  }

  static Future<bool> logoutUser(User user) async {
    await Future.delayed(Duration(seconds: 5));
    return true;
  }

  static Future<String> signupUser(Map data) async {
    Map<String, dynamic> form_data = {
      'email': data['email'],
      'password': data['password']
    };
    var response = await dio.post(api_endpoint_user_sign,
        data: FormData.fromMap(form_data));
    print(response);
    String error_msg = '';
    Map ret_data = jsonDecode(response.toString());
    if (ret_data['status'] == 200) {
      Map<String, dynamic> data = ret_data['data'];
      if (prefs != null) {
        prefs!.setString("user_id", "${data['id']}");
        prefs!.setString("user_email", data['email']);
        prefs!.setString("user_password", data['password']);
      }
      return 'success';
    }
    error_msg = ret_data?['message'];
    return 'Error : $error_msg';
  }
}
